#ifndef FT_IRC_HPP
#define FT_IRC_HPP

#include "ircserver.hpp"
#include "ircchannel.hpp"
#include "ircclient.hpp"
#include "ircevent.hpp"
#include "ircsocket.hpp"
#include "ircmessage.hpp"
#include "irclog.hpp"
#include "irccommand.hpp"
#include "ircutils.hpp"

#endif