#include "../../includes/irccommand.hpp"
void
    IRCCommand::notice()
{
    privmsg();
}
